import React from 'react';
import "./User.css"

const User = ({ user }) => {
    return (
        <div className="user">
            <h3>{user.name}</h3>
            <p>Email: {user.email}</p>
        </div>
    );
};

export default User;
