import React from 'react';
import "./Comment.css"

const Comment = ({ comment }) => {
    return (
        <div className="comment">
            <p>{comment.user}: {comment.text}</p>
        </div>
    );
};

export default Comment;
