import React from 'react';
import "./Like.css"

const Like = ({ like }) => {
    return (
        <div className="like">
            <p>{like.user} liked this post.</p>
        </div>
    );
};

export default Like;
