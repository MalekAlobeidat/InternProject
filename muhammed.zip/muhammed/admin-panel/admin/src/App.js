import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Post from './components/Post';
import User from './components/User';
import Like from './components/Like';
import Comment from './components/Comment';
import './App.css';

const App = () => {
  const [data, setData] = useState([]);
  const [analyticsReport, setAnalyticsReport] = useState({});

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get('/api/analytics/report');
        const analyticsData = response.data;

        setData([
          { user: analyticsData.newUsersThisMonth },
          { user: analyticsData.usersInLastWeek },
          { post: analyticsData.highestLikesPost },
          { post: analyticsData.lowestLikedPost },
          { post: analyticsData.highestCommentsPost },
          { post: analyticsData.lowestCommentsPost },
          { totalPosts: analyticsData.totalPosts },
          { totalLikes: analyticsData.totalLikes },
          { topTenAccounts: analyticsData.topTenAccounts },
        ]);

        setAnalyticsReport({
          newUsersThisMonth: analyticsData.newUsersThisMonth,
          week: analyticsData.usersInLastWeek,
          mostlikedposts: analyticsData.mostLikedPost,
          leastliked: analyticsData.leastLikedPost,
        });
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();
  }, []);

  const deleteRow = (index) => {
    const newData = [...data];
    newData.splice(index, 1);
    setData(newData);
  };

  return (
    <div className="admin-dashboard">
      <h1 className="mb-4">Admin Dashboard</h1>
      <table className="table table-sm">
        <thead>
          <tr>
            <th className="small">New users this month: {analyticsReport.newUsersThisMonth}</th>
            <th className="small">New users this week: {analyticsReport.week}</th>
            <th className="small">Most liked post: {analyticsReport.mostlikedposts}</th>
            <th className="small">Least liked post: {analyticsReport.leastliked}</th>
            <th className="small">Most high comments:</th>
            <th className="small">Most low comments:</th>
            <th className="small">Total posts:</th>
            <th className="small">Total likes:</th>
            <th className="small">Top ten accounts:</th>
          </tr>
        </thead>
        <tbody>
          {data.map((rowData, index) => (
            <tr key={index}>
              <td>{rowData.user && <User user={rowData.user} />}</td>
              <td>{rowData.post && <Post post={rowData.post} />}</td>
              <td>{rowData.post && <Like like={rowData.post.likes_count} />}</td>
              <td>{rowData.post && <Post post={rowData.post} />}</td>
              <td>{rowData.post && <Comment comment={rowData.post.comments_count} />}</td>
              <td>
                <button onClick={() => deleteRow(index)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default App;